package me.opgui;

import org.bukkit.Bukkit;
import org.bukkit.inventory.Inventory;

public class GuiManager {

    public static Inventory mainGui() {
        return Bukkit.createInventory(null, 27, "ADMIN PANEL");
    }
}