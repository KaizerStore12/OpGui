package me.opgui;

import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

public class OpGuiPlugin extends JavaPlugin {

    private static OpGuiPlugin instance;

    public static OpGuiPlugin getInstance() {
        return instance;
    }

    @Override
    public void onEnable() {
        instance = this;
        Bukkit.getPluginManager().registerEvents(new GuiListener(), this);
        Bukkit.getPluginManager().registerEvents(new TempMuteManager(), this);
        DataManager.init();
        SchedulerManager.start();
        getLogger().info("OpGui enabled (skeleton build).");
    }
}