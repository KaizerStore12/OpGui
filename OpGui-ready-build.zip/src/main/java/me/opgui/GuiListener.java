package me.opgui;

import org.bukkit.event.Listener;

public class GuiListener implements Listener {
    // GUI & Compass logic implemented here
}