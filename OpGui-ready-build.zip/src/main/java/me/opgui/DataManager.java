package me.opgui;

public class DataManager {
    public static void init() {
        // Load/save YAML data
    }
}