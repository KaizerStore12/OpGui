package me.opgui;

import java.util.UUID;

public class ConfirmData {
    public static String action;
    public static String target;
    public static int days;
    public static UUID staff;
}