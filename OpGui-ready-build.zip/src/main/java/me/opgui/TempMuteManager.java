package me.opgui;

import org.bukkit.event.Listener;

public class TempMuteManager implements Listener {
    // Temp mute logic
}