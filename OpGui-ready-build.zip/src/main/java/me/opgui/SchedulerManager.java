package me.opgui;

public class SchedulerManager {
    public static void start() {
        // Auto-unban scheduler
    }
}