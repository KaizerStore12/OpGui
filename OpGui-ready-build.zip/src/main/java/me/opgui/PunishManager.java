package me.opgui;

public class PunishManager {
    // Kick, TempBan, Mute, Gamemode logic
}